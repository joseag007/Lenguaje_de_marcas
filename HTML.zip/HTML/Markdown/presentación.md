# José
## Alhaurin de la Torre
### Vengo del bachillerato tecnológico y tengo 18 años
Escribe aquí un breve párrafo de presentación.
### Mis comidas favoritas
- pasta
- lasaña
- hamburguesa de ternera
### Enlace de interés
[Visita mi página favorita](https://es.wikipedia.org/wiki/Wikipedia:Portada)
### Imagen que me gusta
![imagen de agujero negro](https://imgs.search.brave.com/rUWQimmtbXemo7fA169kYLa7tiFOUqSFeGdbktuuLFI/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93YWxs/cGFwZXJzLmNvbS9p/bWFnZXMvaGQvNGst/YmxhY2staG9sZS1v/cmFuZ2UtbGlnaHQt/c3RyZWFrcy02Zjdn/bHB1OHp2MjF5MWI2/LmpwZw)