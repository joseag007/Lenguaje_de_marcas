Stand by Me  
Oasis  
Album: Be Here Now  
Año de publicación: 1997  
Compositor: Noel Gallagher

Made a meal and threw it up on Sunday  
I've got a lot of things to learn  
Said I would and I'll be leaving one day  
Before my heart starts to burn  
So what's the matter with you?  
Sing me something new  
Don't you know the cold and wind and rain don't know?  
They only seem to come and go away  
Times are hard when things have got no meaning  
